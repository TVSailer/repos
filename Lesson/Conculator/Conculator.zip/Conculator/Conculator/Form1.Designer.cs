﻿namespace Conculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Button number_1;
            Button Znak_Minus;
            Button Znak_Plus;
            Button number_3;
            Button number_6;
            Button number_5;
            Button number_2;
            Button number_4;
            Button number_0;
            Button button_equals;
            Button Znak_Delit;
            Button Znak_Umnotit;
            Button plusMinus;
            Button button_Drobi;
            Button DeleteSimvol;
            Button button_C;
            Button number_9;
            Button number_8;
            Button number_7;
            Button Color;
            Button M;
            Button MMinus;
            Button MPlus;
            Button MC;
            infoClik = new RichTextBox();
            label1 = new Label();
            info = new Label();
            Buttons = new GroupBox();
            number_1 = new Button();
            Znak_Minus = new Button();
            Znak_Plus = new Button();
            number_3 = new Button();
            number_6 = new Button();
            number_5 = new Button();
            number_2 = new Button();
            number_4 = new Button();
            number_0 = new Button();
            button_equals = new Button();
            Znak_Delit = new Button();
            Znak_Umnotit = new Button();
            plusMinus = new Button();
            button_Drobi = new Button();
            DeleteSimvol = new Button();
            button_C = new Button();
            number_9 = new Button();
            number_8 = new Button();
            number_7 = new Button();
            Color = new Button();
            M = new Button();
            MMinus = new Button();
            MPlus = new Button();
            MC = new Button();
            Buttons.SuspendLayout();
            SuspendLayout();
            // 
            // number_1
            // 
            number_1.FlatStyle = FlatStyle.Flat;
            number_1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_1.Location = new Point(0, 292);
            number_1.Name = "number_1";
            number_1.Size = new Size(86, 48);
            number_1.TabIndex = 0;
            number_1.Text = "1";
            number_1.UseVisualStyleBackColor = false;
            number_1.Click += number_2_Click;
            // 
            // Znak_Minus
            // 
            Znak_Minus.BackColor = SystemColors.AppWorkspace;
            Znak_Minus.FlatStyle = FlatStyle.Flat;
            Znak_Minus.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Znak_Minus.Location = new Point(258, 245);
            Znak_Minus.Name = "Znak_Minus";
            Znak_Minus.Size = new Size(86, 48);
            Znak_Minus.TabIndex = 1;
            Znak_Minus.Text = "-";
            Znak_Minus.UseVisualStyleBackColor = false;
            Znak_Minus.Click += Znak_Minus_Click;
            // 
            // Znak_Plus
            // 
            Znak_Plus.BackColor = SystemColors.AppWorkspace;
            Znak_Plus.FlatStyle = FlatStyle.Flat;
            Znak_Plus.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Znak_Plus.Location = new Point(258, 292);
            Znak_Plus.Name = "Znak_Plus";
            Znak_Plus.Size = new Size(86, 48);
            Znak_Plus.TabIndex = 3;
            Znak_Plus.Text = "+";
            Znak_Plus.UseVisualStyleBackColor = false;
            Znak_Plus.Click += Znak_Plus_Click;
            // 
            // number_3
            // 
            number_3.FlatStyle = FlatStyle.Flat;
            number_3.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_3.Location = new Point(172, 292);
            number_3.Name = "number_3";
            number_3.Size = new Size(86, 48);
            number_3.TabIndex = 5;
            number_3.Text = "3";
            number_3.UseVisualStyleBackColor = false;
            number_3.Click += number_2_Click;
            // 
            // number_6
            // 
            number_6.FlatStyle = FlatStyle.Flat;
            number_6.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_6.Location = new Point(172, 245);
            number_6.Name = "number_6";
            number_6.Size = new Size(86, 48);
            number_6.TabIndex = 6;
            number_6.Text = "6";
            number_6.UseVisualStyleBackColor = false;
            number_6.Click += number_2_Click;
            // 
            // number_5
            // 
            number_5.FlatStyle = FlatStyle.Flat;
            number_5.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_5.Location = new Point(86, 245);
            number_5.Name = "number_5";
            number_5.Size = new Size(86, 48);
            number_5.TabIndex = 9;
            number_5.Text = "5";
            number_5.UseVisualStyleBackColor = false;
            number_5.Click += number_2_Click;
            // 
            // number_2
            // 
            number_2.FlatStyle = FlatStyle.Flat;
            number_2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_2.Location = new Point(86, 292);
            number_2.Name = "number_2";
            number_2.Size = new Size(86, 48);
            number_2.TabIndex = 12;
            number_2.Text = "2";
            number_2.UseVisualStyleBackColor = false;
            number_2.Click += number_2_Click;
            // 
            // number_4
            // 
            number_4.FlatStyle = FlatStyle.Flat;
            number_4.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_4.Location = new Point(0, 245);
            number_4.Name = "number_4";
            number_4.Size = new Size(86, 48);
            number_4.TabIndex = 8;
            number_4.Text = "4";
            number_4.UseVisualStyleBackColor = false;
            number_4.Click += number_2_Click;
            // 
            // number_0
            // 
            number_0.FlatStyle = FlatStyle.Flat;
            number_0.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_0.Location = new Point(86, 339);
            number_0.Name = "number_0";
            number_0.Size = new Size(86, 48);
            number_0.TabIndex = 13;
            number_0.Text = "0";
            number_0.UseVisualStyleBackColor = false;
            number_0.Click += number_2_Click;
            // 
            // button_equals
            // 
            button_equals.BackColor = SystemColors.ActiveCaptionText;
            button_equals.FlatStyle = FlatStyle.Popup;
            button_equals.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button_equals.ForeColor = SystemColors.Control;
            button_equals.Location = new Point(258, 340);
            button_equals.Name = "button_equals";
            button_equals.Size = new Size(86, 48);
            button_equals.TabIndex = 2;
            button_equals.Text = "=";
            button_equals.UseVisualStyleBackColor = false;
            button_equals.Click += button_equals_Click;
            // 
            // Znak_Delit
            // 
            Znak_Delit.BackColor = SystemColors.AppWorkspace;
            Znak_Delit.FlatStyle = FlatStyle.Flat;
            Znak_Delit.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Znak_Delit.Location = new Point(258, 151);
            Znak_Delit.Name = "Znak_Delit";
            Znak_Delit.Size = new Size(86, 48);
            Znak_Delit.TabIndex = 14;
            Znak_Delit.Text = "÷";
            Znak_Delit.UseVisualStyleBackColor = false;
            Znak_Delit.Click += Znak_Delit_Click;
            // 
            // Znak_Umnotit
            // 
            Znak_Umnotit.BackColor = SystemColors.AppWorkspace;
            Znak_Umnotit.FlatStyle = FlatStyle.Flat;
            Znak_Umnotit.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Znak_Umnotit.Location = new Point(258, 198);
            Znak_Umnotit.Name = "Znak_Umnotit";
            Znak_Umnotit.Size = new Size(86, 48);
            Znak_Umnotit.TabIndex = 19;
            Znak_Umnotit.Text = "×";
            Znak_Umnotit.UseVisualStyleBackColor = false;
            Znak_Umnotit.Click += Znak_Umnotit_Click;
            // 
            // plusMinus
            // 
            plusMinus.BackColor = SystemColors.AppWorkspace;
            plusMinus.FlatStyle = FlatStyle.Flat;
            plusMinus.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            plusMinus.Location = new Point(0, 151);
            plusMinus.Name = "plusMinus";
            plusMinus.Size = new Size(86, 48);
            plusMinus.TabIndex = 16;
            plusMinus.Text = "±";
            plusMinus.UseVisualStyleBackColor = false;
            plusMinus.Click += plusMinus_Click;
            // 
            // button_Drobi
            // 
            button_Drobi.BackColor = SystemColors.AppWorkspace;
            button_Drobi.FlatStyle = FlatStyle.Flat;
            button_Drobi.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button_Drobi.Location = new Point(172, 339);
            button_Drobi.Name = "button_Drobi";
            button_Drobi.Size = new Size(86, 48);
            button_Drobi.TabIndex = 15;
            button_Drobi.Text = ",";
            button_Drobi.UseVisualStyleBackColor = false;
            button_Drobi.Click += button_Drobi_Click;
            // 
            // DeleteSimvol
            // 
            DeleteSimvol.BackColor = SystemColors.AppWorkspace;
            DeleteSimvol.FlatStyle = FlatStyle.Flat;
            DeleteSimvol.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            DeleteSimvol.Location = new Point(172, 151);
            DeleteSimvol.Name = "DeleteSimvol";
            DeleteSimvol.Size = new Size(86, 48);
            DeleteSimvol.TabIndex = 17;
            DeleteSimvol.Text = "<";
            DeleteSimvol.UseVisualStyleBackColor = false;
            DeleteSimvol.Click += DeleteSimvol_Click;
            // 
            // button_C
            // 
            button_C.BackColor = SystemColors.AppWorkspace;
            button_C.FlatStyle = FlatStyle.Flat;
            button_C.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button_C.Location = new Point(86, 151);
            button_C.Name = "button_C";
            button_C.Size = new Size(86, 48);
            button_C.TabIndex = 18;
            button_C.Text = "C";
            button_C.UseVisualStyleBackColor = false;
            button_C.Click += button_C_Click;
            // 
            // number_9
            // 
            number_9.FlatStyle = FlatStyle.Flat;
            number_9.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_9.Location = new Point(172, 198);
            number_9.Name = "number_9";
            number_9.Size = new Size(86, 48);
            number_9.TabIndex = 21;
            number_9.Text = "9";
            number_9.UseVisualStyleBackColor = false;
            number_9.Click += number_2_Click;
            // 
            // number_8
            // 
            number_8.FlatStyle = FlatStyle.Flat;
            number_8.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_8.Location = new Point(86, 198);
            number_8.Name = "number_8";
            number_8.Size = new Size(86, 48);
            number_8.TabIndex = 22;
            number_8.Text = "8";
            number_8.UseVisualStyleBackColor = false;
            number_8.Click += number_2_Click;
            // 
            // number_7
            // 
            number_7.FlatStyle = FlatStyle.Flat;
            number_7.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            number_7.Location = new Point(0, 198);
            number_7.Name = "number_7";
            number_7.Size = new Size(86, 48);
            number_7.TabIndex = 23;
            number_7.Text = "7";
            number_7.UseVisualStyleBackColor = false;
            number_7.Click += number_2_Click;
            // 
            // Color
            // 
            Color.BackColor = SystemColors.WindowFrame;
            Color.FlatStyle = FlatStyle.Flat;
            Color.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Color.Location = new Point(0, 339);
            Color.Name = "Color";
            Color.Size = new Size(86, 48);
            Color.TabIndex = 24;
            Color.Text = "Color";
            Color.UseVisualStyleBackColor = false;
            Color.Click += Color_Click;
            // 
            // M
            // 
            M.BackColor = SystemColors.WindowFrame;
            M.FlatStyle = FlatStyle.Flat;
            M.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            M.Location = new Point(258, 104);
            M.Name = "M";
            M.Size = new Size(86, 48);
            M.TabIndex = 25;
            M.Text = "M";
            M.UseVisualStyleBackColor = false;
            M.Click += M_Click;
            // 
            // MMinus
            // 
            MMinus.BackColor = SystemColors.WindowFrame;
            MMinus.FlatStyle = FlatStyle.Flat;
            MMinus.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            MMinus.Location = new Point(172, 104);
            MMinus.Name = "MMinus";
            MMinus.Size = new Size(86, 48);
            MMinus.TabIndex = 26;
            MMinus.Text = "M-";
            MMinus.UseVisualStyleBackColor = false;
            MMinus.Click += MMinus_Click;
            // 
            // MPlus
            // 
            MPlus.BackColor = SystemColors.WindowFrame;
            MPlus.FlatStyle = FlatStyle.Flat;
            MPlus.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            MPlus.Location = new Point(86, 104);
            MPlus.Name = "MPlus";
            MPlus.Size = new Size(86, 48);
            MPlus.TabIndex = 27;
            MPlus.Text = "M+";
            MPlus.UseVisualStyleBackColor = false;
            MPlus.Click += MPlus_Click;
            // 
            // MC
            // 
            MC.BackColor = SystemColors.WindowFrame;
            MC.FlatStyle = FlatStyle.Flat;
            MC.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            MC.Location = new Point(0, 104);
            MC.Name = "MC";
            MC.Size = new Size(86, 48);
            MC.TabIndex = 28;
            MC.Text = "MC";
            MC.UseVisualStyleBackColor = false;
            // 
            // infoClik
            // 
            infoClik.BorderStyle = BorderStyle.None;
            infoClik.Cursor = Cursors.IBeam;
            infoClik.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            infoClik.Location = new Point(0, 0);
            infoClik.Name = "infoClik";
            infoClik.Size = new Size(345, 106);
            infoClik.TabIndex = 20;
            infoClik.Text = "";
            infoClik.KeyPress += infoClik_KeyPress;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(199, 50);
            label1.Name = "label1";
            label1.Size = new Size(0, 25);
            label1.TabIndex = 22;
            // 
            // info
            // 
            info.AutoSize = true;
            info.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            info.Location = new Point(1, 0);
            info.Name = "info";
            info.Size = new Size(0, 32);
            info.TabIndex = 23;
            info.TextAlign = ContentAlignment.TopRight;
            // 
            // Buttons
            // 
            Buttons.BackColor = SystemColors.Control;
            Buttons.Controls.Add(MC);
            Buttons.Controls.Add(MPlus);
            Buttons.Controls.Add(MMinus);
            Buttons.Controls.Add(M);
            Buttons.Controls.Add(Color);
            Buttons.Controls.Add(number_7);
            Buttons.Controls.Add(number_8);
            Buttons.Controls.Add(infoClik);
            Buttons.Controls.Add(number_9);
            Buttons.Controls.Add(button_C);
            Buttons.Controls.Add(DeleteSimvol);
            Buttons.Controls.Add(button_Drobi);
            Buttons.Controls.Add(plusMinus);
            Buttons.Controls.Add(Znak_Umnotit);
            Buttons.Controls.Add(Znak_Delit);
            Buttons.Controls.Add(button_equals);
            Buttons.Controls.Add(number_0);
            Buttons.Controls.Add(number_4);
            Buttons.Controls.Add(number_2);
            Buttons.Controls.Add(number_5);
            Buttons.Controls.Add(number_6);
            Buttons.Controls.Add(number_3);
            Buttons.Controls.Add(Znak_Plus);
            Buttons.Controls.Add(Znak_Minus);
            Buttons.Controls.Add(number_1);
            Buttons.Location = new Point(1, 50);
            Buttons.Name = "Buttons";
            Buttons.Size = new Size(345, 387);
            Buttons.TabIndex = 21;
            Buttons.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = SystemColors.Control;
            ClientSize = new Size(346, 444);
            Controls.Add(info);
            Controls.Add(label1);
            Controls.Add(Buttons);
            MaximizeBox = false;
            MaximumSize = new Size(368, 500);
            Name = "Form1";
            StartPosition = FormStartPosition.WindowsDefaultBounds;
            Text = " Конкулятор";
            WindowState = FormWindowState.Maximized;
            Buttons.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox infoClik;
        private Label label1;
        private Label info;
        private GroupBox Buttons;
    }
}