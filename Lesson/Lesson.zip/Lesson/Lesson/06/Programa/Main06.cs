﻿

namespace Lesson._06
{
    class Main06
    {
        public static void Run()
        {
            Conculator conculator = new Conculator();
            conculator.ReadInfo();
        }
    }
}
