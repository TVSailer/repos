﻿
namespace Lesson._06
{
    interface IObjekt
    {
        double Run(double[] param);
        bool ChekZnak(string operetion);
        int CountParam { get; }
    }
}
