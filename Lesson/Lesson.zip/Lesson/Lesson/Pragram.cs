﻿using Lesson._08;
using Lesson._06;
using Lesson._07;
using Lesson._09;

internal class Program
{
    private static void Main(string[] args)
    {
        //Main06.Run();
        //Main07.Run();
        //Main08.Run();
        Main09.Run();
    }
}
