﻿

namespace Lesson._09
{
    class Main09
    {
        public static void Run()
        {
            Conculator conculator = new Conculator();
            conculator.RunCon();
        }
       
    }
}
