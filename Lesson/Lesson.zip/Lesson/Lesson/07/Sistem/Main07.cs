﻿

namespace Lesson._07
{
    class Main07
    {
        public static void Run()
        {
            Conculator conculator = new Conculator();
            conculator.RunCon();
        }
       
    }
}
