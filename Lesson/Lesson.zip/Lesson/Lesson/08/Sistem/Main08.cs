﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson._08
{
    internal class Main08
    {
        public static void Run()
        {
            Animals animals = new Animals();
            animals.InfoComand();
        }
    }
}
